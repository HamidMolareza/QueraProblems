from django.db import models


class RoleType(models.IntegerChoices):
    pass


class Category(models.Model):
    pass


class Project(models.Model):
    pass


class Membership(models.Model):
    pass
