from rest_framework import serializers


class ProjectSerializer(serializers.ModelSerializer):
    pass
