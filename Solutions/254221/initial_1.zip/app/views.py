from rest_framework.generics import ListAPIView


class ProjectListView(ListAPIView):
    pass
